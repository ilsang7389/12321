package exam;

public interface BIzService {
	public void  securityMethod();

}
